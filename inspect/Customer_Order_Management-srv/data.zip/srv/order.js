const cds = require('@sap/cds');
const { UPDATE } = require('@sap/cds/lib/ql/cds-ql');

module.exports = cds.service.impl(async function () {
    const { SalesOrders, Products, OrderItems, Customers,  Addresses } = this.entities();
    const {Invoices} = this.entities('InvoiceService');

this.before('SAVE', 'SalesOrders', async (req) => {

    const order = req.data;

    // Customer validation
    if (!order.Customer_ID) {
        req.error(
            400,
            'Customer is required'
        );
    }

    // Fetch shipping address
    const shippingAddress = await SELECT.one
        .from(Addresses)
        .where({
            Customer_ID: order.Customer_ID,
            AddressType: 'SHIPPING'
        });

    if (!shippingAddress) {
        req.error(
            400,
            'Customer shipping address not found'
        );
    }

    // Store address snapshot
    order.ShippingAddress =
        `${shippingAddress.AddressLine1},
         ${shippingAddress.City},
         ${shippingAddress.State},
         ${shippingAddress.Country}`;
});

// this.before('CREATE', 'OrderItems', async (req) => {

//     const product = await SELECT.one
//         .from('Products')
//         .where({ ID: req.data.Product_ID });

//     req.data.UnitPrice = product.UnitPrice;

//     req.data.LineTotal =
//         (req.data.Quantity * product.UnitPrice) - (req.data.Discount || 0);
// });
  
// this.before(['CREATE', 'UPDATE'], 'OrderItems', (req) => {

//     const { Quantity, UnitPrice, Discount = 0 } = req.data;

//     if (Quantity != null || UnitPrice != null || Discount != null) {
//         req.data.LineTotal =
//             (Quantity * UnitPrice) - Discount;
//     }
// });

// this.after(['CREATE', 'UPDATE', 'DELETE'], 'OrderItems', async (data) => {

//     const orderID = data.SalesOrder_ID;

//     const items = await SELECT
//         .from('OrderItems')
//         .columns('LineTotal')
//         .where({ SalesOrder_ID: orderID });

//     const total = items.reduce((sum, i) => sum + i.LineTotal, 0);

//     await UPDATE('SalesOrders')
//         .set({ TotalAmount: total })
//         .where({ ID: orderID });
// });


//
// CONFIRM ORDER
//

this.before('PATCH', 'OrderItems.drafts', async (req) => {

    const existing = await SELECT.one.from(OrderItems.drafts).where({ ID: req.data.ID });

    const salesOrder_ID =
        req.data.Order_ID ??
        existing?.Order_ID ??
        existing?.Order?.ID;

    if (!salesOrder_ID) return;

    const order = await SELECT.one
        .from(SalesOrders)
        .where({ ID: salesOrder_ID });

    if (!order) {
        return req.error(404, 'Sales order not found');
    }

    if (order.Status !== 'NEW') {
        return req.error(400, 'Order items can only be edited in NEW status');
    }

    const product_ID = req.data.Product_ID ?? existing?.Product_ID;
    const quantity = req.data.Quantity ?? existing?.Quantity ?? 0;
    const discount = req.data.Discount ?? existing?.Discount ?? 0;

    if (!product_ID) return;

    const product = await SELECT.one
        .from(Products)
        .where({ ID: product_ID });

    if (!product) {
        return req.error(404, 'Product not found');
    }

    req.data.UnitPrice = product.UnitPrice;

    const lineTotal = (quantity * product.UnitPrice) - discount;
    req.data.LineTotal = Number(lineTotal.toFixed(2));

    // IMPORTANT FIX: don't filter by salesOrder_ID directly
    const items = await SELECT
        .from(OrderItems.drafts)
        .where({ Order_ID: salesOrder_ID });

    let totalAmount = 0;

    for (const item of items) {
        if (item.ID === req.data.ID) continue;
        totalAmount += item.LineTotal || 0;
    }

    totalAmount += req.data.LineTotal;

    await UPDATE(SalesOrders.drafts)
        .set({
            TotalAmount: Number(totalAmount.toFixed(2))
        })
        .where({ ID: salesOrder_ID });
});
 

this.before('DELETE', 'OrderItems.drafts', async (req) => {

    const existing = await SELECT.one.from(OrderItems.drafts).where({ ID: req.data.ID });

    if (!existing?.Order_ID) return;

    const items = await SELECT
        .from(OrderItems.drafts)
        .where({ Order_ID: existing.Order_ID });

    let totalAmount = 0;

    for (const item of items) {
        if (item.ID === existing.ID) continue;
        totalAmount += item.LineTotal || 0;
    }

    await UPDATE(SalesOrders.drafts)
        .set({
            TotalAmount: Number(totalAmount.toFixed(2))
        })
        .where({ ID: existing.Order_ID });
});

this.before('confirmOrder', async (req) => {

    const orderID = req.params[0].ID;

    // Fetch order
    const order = await SELECT.one
        .from(SalesOrders)
        .where({ ID: orderID });

    if (!order) {
        req.error(404, 'Order not found');
    }

    // Status validations
    if (order.Status === 'CANCELLED') {

        req.error(
            400,
            'Cancelled order cannot be confirmed'
        );
    }

    if (
        order.Status === 'PROCESSING' ||
        order.Status === 'SHIPPED' ||
        order.Status === 'DELIVERED'
    ) {

        req.error(
            400,
            `Order already ${order.Status}`
        );
    }

    // Fetch customer
    const customer = await SELECT.one
        .from(Customers)
        .where({
            ID: order.Customer_ID
        });

    if (!customer) {

        req.error(
            404,
            'Customer not found'
        );
    }

    // Credit limit validation
    if (
        order.TotalAmount >
        customer.CreditLimit
    ) {

        req.error(
            400,
            'Order amount exceeds customer credit limit'
        );
    }

    // Fetch items
    const items = await SELECT
        .from(OrderItems)
        .where({
            Order_ID: orderID
        });

    // Stock validation
    for (const item of items) {

        const product = await SELECT.one
            .from(Products)
            .where({
                ID: item.Product_ID
            });

        if (!product) {

            req.error(
                404,
                `Product not found for item ${item.ID}`
            );
        }

        if (
            product.StockQty <
            item.Quantity
        ) {

            req.error(
                400,
                `Insufficient stock for ${product.Name}`
            );
        }
    }
});

this.on('confirmOrder', async (req) => {

    const orderID = req.params[0].ID;

    // Fetch items
    const items = await SELECT
        .from(OrderItems)
        .where({
            Order_ID: orderID
        });

    // Reduce stock
    for (const item of items) {

        const product = await SELECT.one
            .from(Products)
            .where({
                ID: item.Product_ID
            });

        await UPDATE(Products)
            .set({
                StockQty:
                    product.StockQty -
                    item.Quantity
            })
            .where({
                ID: item.Product_ID
            });
    }

    // Update status
    await UPDATE(SalesOrders)
        .set({
            Status: 'PROCESSING'
        })
        .where({
            ID: orderID
        });

    return 'Order confirmed successfully';
});


//
// SHIP ORDER
//
this.on('shipOrder', async (req) => {

    const orderID = req.params[0].ID;

    // Fetch order
    const order = await SELECT.one
        .from(SalesOrders)
        .where({
            ID: orderID
        });

    if (!order) {
        req.error(404, 'Order not found');
    }

    // Validation
    if (order.Status === 'CANCELLED') {

        req.error(
            400,
            'Cancelled order cannot be shipped'
        );
    }

    if (order.Status !== 'PROCESSING') {

        req.error(
            400,
            'Only confirmed orders can be shipped'
        );
    }

    // Update status
    await UPDATE(SalesOrders)
        .set({
            Status: 'SHIPPED'
        })
        .where({
            ID: orderID
        });

    return 'Order shipped successfully';
});


//
// DELIVER ORDER
//
this.before('deliverOrder', async (req) => {

    const orderID = req.params[0].ID;

    const order = await SELECT.one
        .from(SalesOrders)
        .where({ ID: orderID });

    if (!order) {
        req.error(404, 'Order not found');
    }

    if (order.Status !== 'SHIPPED') {
        req.error(400, 'Only shipped orders can be delivered');
    }

    // attach to request so later handlers can reuse it
    req.data._order = order;
});


this.on('deliverOrder', async (req) => {

    const orderID = req.params[0].ID;

    await UPDATE(SalesOrders)
        .set({ Status: 'DELIVERED' })
        .where({ ID: orderID });

    return 'Order delivered successfully';
});

this.after('deliverOrder', async (data, req) => {

    const orderID = req.params[0].ID;

    const order = req.data._order;

    const existingInvoice = await SELECT.one
        .from(Invoices)
        .where({ SalesOrder_ID: orderID });

    if (existingInvoice) return;

    const today = new Date();

    const invoiceDate = today.toISOString().split('T')[0];

    const dueDate = new Date();
    dueDate.setDate(today.getDate() + 7);

    await INSERT.into(Invoices).entries({
        SalesOrder_ID: orderID,
        InvoiceDate: invoiceDate,
        DueDate: dueDate.toISOString().split('T')[0],
        TotalAmount: order.TotalAmount,
        TaxAmount: 0,
        Status: 'GENERATED'
    });
});

//
// CANCEL ORDER
//
this.on('cancelOrder', async (req) => {

    const orderID = req.params[0].ID;

    const { reason } = req.data;

    // Fetch order
    const order = await SELECT.one
        .from(SalesOrders)
        .where({
            ID: orderID
        });

    if (!order) {
        req.error(404, 'Order not found');
    }

    // Validation
    if (order.Status === 'DELIVERED') {

        req.error(
            400,
            'Delivered order cannot be cancelled'
        );
    }

    if (order.Status === 'CANCELLED') {

        req.error(
            400,
            'Order already cancelled'
        );
    }

    // Restore stock
    const items = await SELECT
        .from(OrderItems)
        .where({
            Order_ID: orderID
        });

    for (const item of items) {

        const product = await SELECT.one
            .from(Products)
            .where({
                ID: item.Product_ID
            });

        await UPDATE(Products)
            .set({
                StockQty:
                    product.StockQty +
                    item.Quantity
            })
            .where({
                ID: item.Product_ID
            });
    }

    // Update status
    await UPDATE(SalesOrders)
        .set({
            Status: 'CANCELLED'
        })
        .where({
            ID: orderID
        });

    console.log(
        'Cancellation Reason:',
        reason
    );

    return 'Order cancelled successfully';
});

});